local Bayes = {}

InteractionGraph = require "InteractionGraph"



return Bayes
